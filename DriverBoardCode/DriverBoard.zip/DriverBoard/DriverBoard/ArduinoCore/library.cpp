/*
 * ArduinoCore.cpp
 *
 * Created: 18.09.2022 11:32:18
 * Author : sWe
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

